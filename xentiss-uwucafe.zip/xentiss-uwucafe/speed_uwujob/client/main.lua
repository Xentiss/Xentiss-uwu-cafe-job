local PlayerData, GUI, CurrentActionData, JobBlips = {}, {}, {}, {}
ESX = nil
GUI.Time = 0

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function OpenCloakroomMenu()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'Szatnia', {
			title    = ('Szatnia'),
			align    = 'center',
			elements = {
				{label = ('Strój osobisty'), value = 'citizen_wear'},
				{label = ('Strój służbowy'), value = 'kawiarnia_wear'},
			},
		}, function(data, menu)

			menu.close()

			if data.current.value == 'citizen_wear' then
				ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
					TriggerEvent('skinchanger:loadSkin', skin)
				end)
			end

			if data.current.value == 'kawiarnia_wear' then
				ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
					if skin.sex == 0 then
						TriggerEvent('skinchanger:loadClothes', skin, jobSkin.skin_male)
					else
						TriggerEvent('skinchanger:loadClothes', skin, jobSkin.skin_female)
					end
				end)
			end

			CurrentAction     = 'kawiarnia_actions_menu'
			CurrentActionData = {}
		end, function(data, menu)
			menu.close()
		end)
end

function OpenKawiarniaActionsMenu()

	local elements = {
        {label = ('Szatnia'), value = 'cloakroom'}
	}

	ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'kawiarnia_actions', {
			title    = 'Kawiarnia',
			align    = 'center',
			elements = elements
		}, function(data, menu)

			if data.current.value == 'cloakroom' then
				OpenCloakroomMenu()
			end


		end, function(data, menu)

			menu.close()

			CurrentAction     = 'kawiarnia_actions_menu'
			CurrentActionData = {}
		end)
end







RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer

end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job

end)





Citizen.CreateThread(function()

    sellblip = AddBlipForCoord(2243.446044, 5154.184570, 57.874024)
	SetBlipSprite(sellblip, 628)
	SetBlipColour(sellblip, 83)
	SetBlipScale(sellblip, 0.8)
	SetBlipAsShortRange(sellblip, true)
	BeginTextCommandSetBlipName('STRING')
	AddTextComponentString('Sprzedawanie Kawy') 
	EndTextCommandSetBlipName(sellblip)
end)


AddEventHandler('bosek')
RegisterNetEvent('bosek', function()
	OpenManageMenu()
end)

function OpenManageMenu()
	ESX.UI.Menu.CloseAll()
	local elements = {
		{ label = 'Akcje Szefa', value = 'bossmenu'},
	}

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'kawiarnia',
	{
		title    = 'Zarządzanie',
		align    = 'center',
		elements = elements

	}, function(data, menu)
		if data.current.value == 'bossmenu' then
			if ESX.PlayerData.job == 'kawiarnia' and ESX.PlayerData.job.grade == '3' then
			end

			TriggerEvent('esx_society:openBossMenu', 'kawiarnia', function(data, menu)
				menu.close()
				CurrentAction     = 'menu_boss_actions'
				CurrentActionMsg  = _U('open_bossmenu')
				CurrentActionData = {}
			end)
	end
		menu.close()
	end)
end



RegisterNetEvent('szatniakawa')
AddEventHandler('szatniakawa', function()
OpenKawiarniaActionsMenu()
end)

RegisterNetEvent('selka')
AddEventHandler('selka', function()
	TriggerServerEvent('esx_kawiarnia:startSell')
end)

RegisterNetEvent('kawa')
AddEventHandler('kawa', function()
 exports["memorygame"]:thermiteminigame(5, 3, 3, 5,
    function() -- success
        TriggerServerEvent('kawa')
    end,
    function() -- failure
        print("fail")
    end)
end)

RegisterNetEvent('kawa2')
AddEventHandler('kawa2', function()
 exports["memorygame"]:thermiteminigame(5, 3, 3, 5,
    function() -- success
        TriggerServerEvent('kawa2')
    end,
    function() -- failure
        print("fail")
    end)
end)

RegisterNetEvent('kawa3')
AddEventHandler('kawa3', function()
 exports["memorygame"]:thermiteminigame(5, 3, 3, 5,
    function() -- success
        TriggerServerEvent('kawa3')
    end,
    function() -- failure
        print("fail")
    end)
end)

RegisterNetEvent('kawa4')
AddEventHandler('kawa4', function()
 exports["memorygame"]:thermiteminigame(5, 3, 3, 5,
    function() -- success
        TriggerServerEvent('kawa4')
    end,
    function() -- failure
        print("fail")
    end)
end)

RegisterNetEvent('givetorba')
AddEventHandler('givetorba', function()
        TriggerServerEvent('torebka')
end)



exports.qtarget:AddBoxZone("KawaSzatnia", vector3(-586.54, -1050.18, 22.34), 2, 2, {
	name="KawaSzatnia",
	heading=1.0,
	debugPoly=false,
	minZ=21.34,
	maxZ=23.34,
	}, {
		options = {
			{
				event = "szatniakawa",
				icon = "fas fa-sign-in-alt",
				label = "Szafka",
				job = "kawiarnia",
			},
		},
		distance = 3.5
})

exports.qtarget:AddBoxZone("KawaTworzenie", vector3(-591.67, -1056.02, 22.34), 2, 2, {
	name="KawaTworzenie",
	heading=0.0,
	debugPoly=false,
  minZ = 21.34,
  maxZ = 23.34,
	}, {
		options = {
			{
				event = "kawa",
				icon = "fas fa-sign-in-alt",
				label = "Zmiel nasiona",
				job = "kawiarnia",
			},
			{
				event = "kawa2",
				icon = "fas fa-sign-in-alt",
				label = "Kawa ",
				job = "kawiarnia",
			},
			{
				event = "kawa3",
				icon = "fas fa-sign-in-alt",
				label = "Kawa Latte ",
				job = "kawiarnia",
			},
			{
				event = "kawa4",
				icon = "fas fa-sign-in-alt",
				label = "Kawa Cappucino",
				job = "kawiarnia",
			},


		},
		distance = 3.5
})

exports.qtarget:AddBoxZone("KawaTworzenieee", vector3(2243.81, 5154.87, 57.68), 3, 2, {
	name="KawaTworzenieee",
	heading=0.0,
	debugPoly=false,
  	minZ = 56.68,
  	maxZ = 58.68,
	}, {
		options = {
			{
				event = "selka",
				icon = "fas fa-sign-in-alt",
				label = "Sprzedaj Kawe",
				job = "kawiarnia",
			},
		},
		distance = 3.5
})


exports.qtarget:AddBoxZone("KawaTworzenieeeee", vector3(-595.95, -1052.9, 22.34), 2, 2, {
	name="KawaTworzenieeeee",
	heading=0.0,
	debugPoly=false,
  	minZ = 21.34,
  	maxZ = 23.34,
	}, {
		options = {
			{
				event = "bosek",
				icon = "fas fa-sign-in-alt",
				label = "Menu szefa",
				job = "kawiarnia",
			},
		},
		distance = 3.5
})


RegisterNetEvent('spawn-car:kaw')
AddEventHandler('spawn-car:kaw', function()
	local coords = vector3(-560.439576, -1073.960450, 22.169190)
	local heading = 184.25196
	if ESX.Game.IsSpawnPointClear(coords, 5) then
	ESX.Game.SpawnVehicle('Rumpo', coords, heading, function(vehicle)
		platenum = math.random(100, 2000)
		local plate =  "Uwu"..platenum
		SetVehicleNumberPlateText(vehicle, plate)
	SetPedIntoVehicle(GetPlayerPed(-1), vehicle, -1)
	TriggerServerEvent('vape-addkeys', plate)
	ambulanceTaken = true
    end)
else
	ESX.ShowNotification('Miejsce wyjmowania pojazdu jest zastawione')
end
end)


exports['qtarget']:AddBoxZone("autakwiarnia", vector3(-567.89, -1071.3, 22.33), 2, 2, {
	name="autakwiarnia",
	heading=0.0,
	--debugPoly=false,
	minZ=21.33,
	maxZ=23.33,
	}, {
		options = {
			{
				event = "spawn-car:kaw",
				icon = "fas fa-hands",
				label = "Wyciągnij pojazd",
				job = "kawiarnia",
			},

			
		},
		distance = 3.0
})


exports['qtarget']:AddBoxZone("torba", vector3(-591.56, -1058.9, 22.34), 2, 2, {
	name="torba",
	heading=0.0,
	--debugPoly=false,
	minZ=21.33,
	maxZ=23.33,
	}, {
		options = {
			{
				event = "givetorba",
				icon = "fas fa-hands",
				label = "Weż torbę",
				job = "kawiarnia",
			},

			
		},
		distance = 3.0
})
