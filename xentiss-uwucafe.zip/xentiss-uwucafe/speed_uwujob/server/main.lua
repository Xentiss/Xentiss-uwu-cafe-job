ESX = nil
local PlayersTransforming, PlayersSelling, PlayersHarvesting = {}, {}, {}
local vine, jus = 1, 1

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

if Config.MaxInService ~= -1 then
	TriggerEvent('esx_service:activateService', 'kawiarnia', Config.MaxInService)
end

TriggerEvent('esx_phone:registerNumber', 'kawiarnia', ('kawiarnia_client'), true, true)
TriggerEvent('esx_society:registerSociety', 'kawiarnia', 'Kawiarnia', 'society_kawiarnia', 'society_kawiarnia', 'society_kawiarnia', {type = 'private'})

local function Sell(source, zone)

	if PlayersSelling[source] == true then
		local xPlayer  = ESX.GetPlayerFromId(source)
		
		if true then
			
			if xPlayer.getInventoryItem('coffee').count <= 0 then
				return
			else
				if (jus == 1) then
					SetTimeout(1100, function()
						local _source = source
						local xPlayer = ESX.GetPlayerFromId(_source)
						local przerobione = xPlayer.getInventoryItem("coffee")
						local ilosc = przerobione.count
						local cena = math.random(205,215)
						local cenaf = math.random(80,85)
						local wcena = cena * ilosc
						local wcenaf = cenaf * ilosc
						local societyAccount = nil

						TriggerEvent('esx_addonaccount:getSharedAccount', 'society_kawiarnia', function(account)
							societyAccount = account
						end)
						if societyAccount ~= nil then
							xPlayer.removeInventoryItem('coffee', ilosc)
							societyAccount.addMoney(wcenaf)
							xPlayer.addMoney(wcena)
							TriggerClientEvent('esx:showNotification', source, 'Zarobiłeś' ..wcena.. '')
							sendToDiscordSELL('KAWIARNIA','[' .. source .. '] ' .. GetPlayerName(source) .. '  Hex: ' .. GetPlayerIdentifier(source) .. ' - Sprzedał ' ..ilosc.. ' paczek kawy i zarobił dla siebie: ' .. wcena .. ' Oraz ' ..wcenaf.. ' dla firmy', 10181046)
						
						end
						Sell(source,zone)
					end)
				end
			end
		end
	end
end

RegisterServerEvent('esx_kawiarnia:startSell')
AddEventHandler('esx_kawiarnia:startSell', function(zone)
	local _source = source

	if PlayersSelling[_source] == false then
		PlayersSelling[_source]=false 
	else
		PlayersSelling[_source]=true
		TriggerClientEvent('esx:showNotification', source, 'Sprzedawanie w toku...')
		Sell(_source)
	end
end)

--SELL--

function sendToDiscordSELL (name,message,color)
	local DiscordWebHook = 'https://discord.com/api/webhooks/928178968903962664/yZZ7dhQ8P2OL3qS2nT0o3xXJH94OfVHrp3S7EwxgsCGyLI1wFtzXUr38tx9w7_1pCdkM'
	local date = os.date('*t')
	if date.month < 10 then date.month = '0' .. tostring(date.month) end
	if date.day < 10 then date.day = '0' .. tostring(date.day) end
	if date.hour < 10 then date.hour = '0' .. tostring(date.hour) end
	if date.min < 10 then date.min = '0' .. tostring(date.min) end
	if date.sec < 10 then date.sec = '0' .. tostring(date.sec) end
	local date = (''..date.day .. '.' .. date.month .. '.' .. date.year .. ' - ' .. date.hour .. ':' .. date.min .. ':' .. date.sec..'')
  
  local embeds = {
	{
		  ["title"]=message,
		  ["type"]="rich",
		  ["color"] =color,
		  ["footer"]=  {
		  ["text"]= "Wysłano o: " ..date.."",
		},
	}
}
  
if message == nil or message == '' then return FALSE end
	PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = name,embeds = embeds}), { ['Content-Type'] = 'application/json' })
end


RegisterServerEvent('kawa')
AddEventHandler('kawa', function(odebrane)
    local xPlayer = ESX.GetPlayerFromId(source)
    local _source = source

    xPlayer.addInventoryItem('kawiarnia_ziarna', 1)
end)


RegisterServerEvent('kawa2')
AddEventHandler('kawa2', function(odebrane)
    local xPlayer = ESX.GetPlayerFromId(source)
    local _source = source
	local item = xPlayer.getInventoryItem("kawiarnia_ziarna")

    if item.count >= 3 then
	xPlayer.removeInventoryItem('kawiarnia_ziarna', 3)
    xPlayer.addInventoryItem('coffee', 1)
	else
		TriggerClientEvent('esx:showNotification', source, 'Masz za mało ziaren')

		end
end)

RegisterServerEvent('kawa3')
AddEventHandler('kawa3', function(odebrane)
    local xPlayer = ESX.GetPlayerFromId(source)
    local _source = source
	local item = xPlayer.getInventoryItem("kawiarnia_ziarna")

    if item.count >= 3 then
	xPlayer.removeInventoryItem('kawiarnia_ziarna', 3)
    xPlayer.addInventoryItem('coffeeee', 1)
	else
		TriggerClientEvent('esx:showNotification', source, 'Masz za mało ziaren')

		end
end)

RegisterServerEvent('kawa4')
AddEventHandler('kawa4', function(odebrane)
    local xPlayer = ESX.GetPlayerFromId(source)
    local _source = source
	local item = xPlayer.getInventoryItem("kawiarnia_ziarna")

    if item.count >= 3 then
	xPlayer.removeInventoryItem('kawiarnia_ziarna', 3)
    xPlayer.addInventoryItem('coffeee', 1)
	else
		TriggerClientEvent('esx:showNotification', source, 'Masz za mało ziaren')

		end
end)


RegisterServerEvent('torebka')
AddEventHandler('torebka', function(odebrane)
    local xPlayer = ESX.GetPlayerFromId(source)
    local _source = source

    xPlayer.addInventoryItem('paperbag', 1)
end)


