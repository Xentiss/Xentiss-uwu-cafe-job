fx_version 'adamant'

game 'gta5'


client_scripts {
  '@es_extended/locale.lua',
  'config.lua',
  'client/main.lua'
}

server_scripts {
  '@es_extended/locale.lua',
  'config.lua',
  'server/main.lua'
}
