Config                            = {}
Config.MaxInService               = -1
Config.EnablePlayerManagement     = true
Config.EnableSocietyOwnedVehicles = false
Config.Zones = {
	Blip = {
		Coords  = vector3(2243.446044, 5154.184570, 57.874024),
		Sprite  = 60,
		Display = 4,
		Scale   = 0.8,
		Colour  = 29
	},
}
